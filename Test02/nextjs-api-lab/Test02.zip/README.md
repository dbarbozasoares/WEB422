<h2>Student name: Diego B Soares</h2><br>
<h2>Student ID: 145820239</h2><br>

<h3>DB String: mongodb+srv://admin:admin@group1dbs311.akbgg.mongodb.net/</h3><br>

<br><br>

1 - So basically on this code we export a function called handler which handles the routes, so we can set GET and POST without needing an ID from query. In other file [id].js that's the one that also export the function handler so here we have a overloading function where this one we handle actions that users pass the id on the query (DELETE id, UPDATE id and GET id)
Other than that, its just a simple API that gets the data from database or get the fields from the body to insert
