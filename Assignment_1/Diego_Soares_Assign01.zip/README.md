node_modules  
.env
